var road = [];

function handleFileSelect(evt) {
  var files = evt.target.files; // FileList object

  // Loop through the FileList and render image files as thumbnails.
  for (var i = 0, f; f = files[i]; i++) {

    // Only process image files.
    if (!f.type.match('image.*')) {
      continue;
    }

    var reader = new FileReader();

    // Closure to capture the file information.
    reader.onload = (function(theFile) {
      return function(e) {
        // Render thumbnail.
        var span = document.createElement('span');
        span.id='photo';
        span.dataset.id = e.target.result;
        span.innerHTML = ['<span class="close"></span><img class="thumb" src="', e.target.result,
                          '" title="', theFile.name, '"/>'].join('');
        road.push( e.target.result);                  
        document.getElementById('list').insertBefore(span, null);
      };
    })(f);
    // Read in the image file as a data URL.
    reader.readAsDataURL(f);
  }
}
var jsonString = JSON.stringify(road);
   $.ajax({
        type: "POST",
        url: "main-page.php",
        data: {data : jsonString}, 
        cache: false,

        success: function(){
            alert("OK");
        }
    });
document.getElementById('files').addEventListener('change', handleFileSelect, false);

document.onclick = function(e) {
  if(e.target.classList.contains('close')) {
    e.target.parentNode.remove();
      road = road.filter(src=> {
         return e.target.parentNode.dataset.id !== src;
       })
      }
      console.log(road);
      
    };
    